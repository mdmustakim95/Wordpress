<?php
//Template Name: Contact page


get_header();
get_header('menubar');

?>

<!-- Header Start -->
<div class="container-fluid bg-breadcrumb">
    <div class="container text-center py-5" style="max-width: 900px;">
        <h3 class="text-white display-3 mb-4 wow fadeInDown" data-wow-delay="0.1s"><?php the_title() ?></h1>
            <ol class="breadcrumb justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                <li class="breadcrumb-item active text-primary"><?php the_title() ?></li>
            </ol>
    </div>
</div>
<!-- Header End -->

<!-- Contact Start -->
<div class="container-fluid contact py-5">
    <div class="container py-5">
        <div class="section-title mb-5 wow fadeInUp" data-wow-delay="0.1s">
            <div class="sub-style mb-4">
                <h4 class="sub-title text-white px-3 mb-0"><?php the_title() ?></h4>
            </div>
            <span class="mb-0 text-black-50"><?php the_content() ?></span>
        </div>
        <div class="row g-4 align-items-center">
            <div class="col-lg-5 col-xl-5 contact-form wow fadeInLeft" data-wow-delay="0.1s">
                <h2 class="display-5 text-white mb-2"><?php the_field('form_title', '31') ?></h2>
                <div class="mb-4 text-white"><?php the_field('form_description', '31') ?></div>
                <form id="contactForm">
                    <div class="row g-3">

                        <div class="col-lg-12 col-xl-6">
                            <div class="form-floating">
                                <input type="text" name="name" class="form-control bg-transparent border border-white" id="name" placeholder="Your Name" required>
                                <label for="name">Your Name</label>
                            </div>
                        </div>

                        <div class="col-lg-12 col-xl-6">
                            <div class="form-floating">
                                <input type="email" name="email" class="form-control bg-transparent border border-white" id="email" placeholder="Your Email" required>
                                <label for="email">Your Email</label>
                            </div>
                        </div>

                        <div class="col-lg-12 col-xl-6">
                            <div class="form-floating">
                                <input type="text" name="phone" class="form-control bg-transparent border border-white" id="phone" placeholder="Phone">
                                <label for="phone">Your Phone</label>
                            </div>
                        </div>

                        <div class="col-lg-12 col-xl-6">
                            <div class="form-floating">
                                <input type="text" name="project" class="form-control bg-transparent border border-white" id="project" placeholder="Project">
                                <label for="project">Your Project</label>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-floating">
                                <input type="text" name="subject" class="form-control bg-transparent border border-white" id="subject" placeholder="Subject">
                                <label for="subject">Subject</label>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-floating">
                                <textarea name="message" class="form-control bg-transparent border border-white" placeholder="Leave a message here" id="message" style="height: 160px"></textarea>
                                <label for="message">Message</label>
                            </div>
                        </div>

                        <div class="col-12">
                            <button type="submit" class="btn btn-light text-primary w-100 py-3">
                                Send Message
                            </button>
                        </div>

                        <!-- Response Message -->
                        <div class="col-12">
                            <div id="form-response"></div>
                        </div>

                    </div>
                </form>
            </div>
            <div class="col-lg-2 col-xl-2 wow fadeInUp" data-wow-delay="0.5s">
                <div class="bg-transparent rounded">
                    <div class="d-flex flex-column align-items-center text-center mb-4">
                        <div class="bg-white d-flex align-items-center justify-content-center mb-3" style="width: 90px; height: 90px; border-radius: 50px;"><i class="fa fa-map-marker-alt fa-2x text-primary"></i></div>
                        <h4 class="text-dark">Addresses</h4>
                        <p class="mb-0 text-white"><?php the_field('address', '31') ?></p>
                    </div>
                    <div class="d-flex flex-column align-items-center text-center mb-4">
                        <div class="bg-white d-flex align-items-center justify-content-center mb-3" style="width: 90px; height: 90px; border-radius: 50px;"><i class="fa fa-phone-alt fa-2x text-primary"></i></div>
                        <h4 class="text-dark">Mobile</h4>
                        <p class="mb-0 text-white"><?php the_field('phone1', '31') ?></p>
                        <p class="mb-0 text-white"><?php the_field('phone2', '31') ?></p>
                    </div>

                    <div class="d-flex flex-column align-items-center text-center">
                        <div class="bg-white d-flex align-items-center justify-content-center mb-3" style="width: 90px; height: 90px; border-radius: 50px;"><i class="fa fa-envelope-open fa-2x text-primary"></i></div>
                        <h4 class="text-dark">Email</h4>
                        <p class="mb-0 text-white"><?php the_field('email1', '31') ?></p>
                        <p class="mb-0 text-white"><?php the_field('email2', '31') ?></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-xl-5 wow fadeInRight" data-wow-delay="0.3s">
                <div class="d-flex justify-content-center mb-4">
                    <a class="btn btn-lg-square btn-light rounded-circle mx-2" href="<?php the_field('facebook', '31') ?>"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-lg-square btn-light rounded-circle mx-2" href="<?php the_field('twitter', '31') ?>"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-lg-square btn-light rounded-circle mx-2" href="<?php the_field('instagram', '31') ?>"><i class="fab fa-instagram"></i></a>
                    <a class="btn btn-lg-square btn-light rounded-circle mx-2" href="<?php the_field('linkedin', '31') ?>"><i class="fab fa-linkedin-in"></i></a>
                </div>
                <div class="rounded h-100">

                    <?php
                    $map = get_field('map', 31);

                    if ($map) {
                        // Add class and style inside iframe tag
                        $map = str_replace(
                            '<iframe',
                            '<iframe class="rounded w-100" style="height: 500px;"',
                            $map
                        );

                        echo $map;
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Contact End -->

<!-- AJAX FORM handler  -->
<script>
    document.getElementById("contactForm").addEventListener("submit", function(e) {
        e.preventDefault();

        let form = this;
        let formData = new FormData(form);

        formData.append("action", "contact_form_submit");

        fetch("<?php echo admin_url('admin-ajax.php'); ?>", {
                method: "POST",
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                document.getElementById("form-response").innerHTML = data.message;

                if (data.success) {
                    form.reset();
                }
            })
            .catch(() => {
                document.getElementById("form-response").innerHTML = "Something went wrong!";
            });
    });
</script>

<?php
get_footer();

?>