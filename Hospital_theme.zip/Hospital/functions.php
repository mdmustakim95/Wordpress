<?php
register_nav_menus(
    array('primary-menu' => 'Top Menu')
);

add_theme_support('post-thumbnails');
add_theme_support('custom-header');


if (!class_exists('Bootstrap_NavWalker')) {

    class Bootstrap_NavWalker extends Walker_Nav_Menu
    {

        function start_lvl(&$output, $depth = 0, $args = null)
        {
            $output .= '<div class="dropdown-menu m-0">';
        }

        function end_lvl(&$output, $depth = 0, $args = null)
        {
            $output .= '</div>';
        }

        function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
        {

            $classes = !empty($item->classes) ? (array) $item->classes : array();

            // Detect dropdown
            $has_children = in_array('menu-item-has-children', $classes);

            // Detect active menu
            $is_active = in_array('current-menu-item', $classes) ||
                in_array('current_page_item', $classes) ||
                in_array('current-menu-parent', $classes) ||
                in_array('current-menu-ancestor', $classes);

            $active_class = $is_active ? ' active' : '';

            if ($depth === 0) {

                if ($has_children) {
                    $output .= '<div class="nav-item dropdown">';
                    $output .= '<a href="#" class="nav-link dropdown-toggle' . $active_class . '" data-bs-toggle="dropdown">'
                        . esc_html($item->title) .
                        '</a>';
                } else {
                    $output .= '<a href="' . esc_url($item->url) . '" class="nav-item nav-link' . $active_class . '">'
                        . esc_html($item->title) .
                        '</a>';
                }
            } else {
                $output .= '<a href="' . esc_url($item->url) . '" class="dropdown-item' . $active_class . '">'
                    . esc_html($item->title) .
                    '</a>';
            }
        }

        function end_el(&$output, $item, $depth = 0, $args = null)
        {

            $classes = !empty($item->classes) ? (array) $item->classes : array();

            if ($depth === 0 && in_array('menu-item-has-children', $classes)) {
                $output .= '</div>';
            }
        }
    }
}

// single services 
function load_custom_treatment_template($template) {
    if (is_singular('service')) {
        $new_template = locate_template(array('single-services.php'));
        if (!empty($new_template)) {
            return $new_template;
        }
    }
    return $template;
}
add_filter('template_include', 'load_custom_treatment_template');

// form hander mail body 
function handle_contact_form_ajax()
{

    $name    = sanitize_text_field($_POST['name']);
    $email   = sanitize_email($_POST['email']);
    $phone   = sanitize_text_field($_POST['phone']);
    $project = sanitize_text_field($_POST['project']);
    $subject = sanitize_text_field($_POST['subject']);
    $message = sanitize_textarea_field($_POST['message']);

    $to = get_option('admin_email');

    $email_subject = "New Contact Form: " . $subject;

    $body = "
    Name: $name
    Email: $email
    Phone: $phone
    Project: $project

    Message:
    $message
    ";

    $headers = ['Content-Type: text/plain; charset=UTF-8'];

    if (wp_mail($to, $email_subject, $body, $headers)) {
        wp_send_json([
            "success" => true,
            "message" => "<span style='color:green;'>Message sent successfully!</span>"
        ]);
    } else {
        wp_send_json([
            "success" => false,
            "message" => "<span style='color:red;'>Failed to send message.</span>"
        ]);
    }
}

add_action('wp_ajax_contact_form_submit', 'handle_contact_form_ajax');
add_action('wp_ajax_nopriv_contact_form_submit', 'handle_contact_form_ajax');
