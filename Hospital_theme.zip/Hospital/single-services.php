<?php
//Template Name: Treatment Page
    get_header();
    get_header('menubar');
?>
        <!-- Header Start -->
        <div class="container-fluid bg-breadcrumb">
            <div class="container text-center py-5" style="max-width: 900px;">
                <h3 class="text-white display-3 mb-4 wow fadeInDown" data-wow-delay="0.1s"><?php the_title() ?></h1>
                <ol class="breadcrumb justify-content-center mb-0 wow fadeInDown" data-wow-delay="0.3s">
                    <li class="breadcrumb-item"><a href="/">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Pages</a></li>
                    <li class="breadcrumb-item active text-primary"><?php the_title() ?></li>
                </ol>    
            </div>
        </div>
        <!-- Header End -->


        <!-- Physiotherapy Service Page Start -->
<div class="container-fluid py-5">
    <div class="container py-5">

        <!-- Page Title -->
        <div class="text-center mb-5">
            <h1 class="display-4 mb-3"><?php the_title() ?></h1>
            <span class="mb-0">
                <?php the_field('short_description') ?>
            </span>
        </div>

        <div class="row g-5 align-items-center">

            <!-- Image -->
            <div class="col-lg-6" style="background-image: url(<?php the_field('treatment_image')?>); background-position:center; object-fit:cover; min-height:450px;">
                <!-- <img src="img/service-2.jpg" class="img-fluid rounded" alt="Physiotherapy"> -->
            </div>

            <!-- Content -->
            <div class="col-lg-6">
                <h2 class="mb-4"><?php the_field('heading') ?></h2>
                <?php the_field('overview') ?>

                <a href="<?php the_field('appointment_link') ?>" class="btn btn-primary rounded-pill px-4 py-2 mt-3">
                    Book Appointment
                </a>
            </div>
        </div>

        <!-- Benefits Section -->
        <div class="row mt-5">
            <div class="col-12 text-center mb-4">
                <h2>Benefits of Physiotherapy</h2>
            </div>

            <div class="col-md-4 text-center">
                <div class="p-4 bg-light rounded">
                    <h5>Pain Relief</h5>
                    <p>Helps reduce chronic and acute pain effectively.</p>
                </div>
            </div>

            <div class="col-md-4 text-center">
                <div class="p-4 bg-light rounded">
                    <h5>Improved Mobility</h5>
                    <p>Enhances flexibility and restores movement.</p>
                </div>
            </div>

            <div class="col-md-4 text-center">
                <div class="p-4 bg-light rounded">
                    <h5>Faster Recovery</h5>
                    <p>Speeds up healing after injuries or surgeries.</p>
                </div>
            </div>
        </div>

    </div>
</div>
<!-- Physiotherapy Service Page End -->




<?php get_footer() ?>